﻿namespace laba_10_2
{
	partial class Form1
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.minutes = new System.Windows.Forms.Button();
			this.minutesInput = new System.Windows.Forms.TextBox();
			this.price = new System.Windows.Forms.Button();
			this.priceInput = new System.Windows.Forms.TextBox();
			this.choice = new System.Windows.Forms.Button();
			this.workday = new System.Windows.Forms.Button();
			this.weekend = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// minutes
			// 
			this.minutes.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.minutes.Location = new System.Drawing.Point(44, 41);
			this.minutes.Name = "minutes";
			this.minutes.Size = new System.Drawing.Size(191, 71);
			this.minutes.TabIndex = 0;
			this.minutes.Text = "Введите количество минут:";
			this.minutes.UseVisualStyleBackColor = true;
			// 
			// minutesInput
			// 
			this.minutesInput.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.minutesInput.Location = new System.Drawing.Point(255, 63);
			this.minutesInput.Name = "minutesInput";
			this.minutesInput.Size = new System.Drawing.Size(104, 27);
			this.minutesInput.TabIndex = 1;
			// 
			// price
			// 
			this.price.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.price.Location = new System.Drawing.Point(44, 120);
			this.price.Name = "price";
			this.price.Size = new System.Drawing.Size(191, 71);
			this.price.TabIndex = 2;
			this.price.Text = "Тариф(руб/мин):";
			this.price.UseVisualStyleBackColor = true;
			// 
			// priceInput
			// 
			this.priceInput.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.priceInput.Location = new System.Drawing.Point(255, 142);
			this.priceInput.Name = "priceInput";
			this.priceInput.Size = new System.Drawing.Size(104, 27);
			this.priceInput.TabIndex = 3;
			// 
			// choice
			// 
			this.choice.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.choice.Location = new System.Drawing.Point(44, 204);
			this.choice.Name = "choice";
			this.choice.Size = new System.Drawing.Size(315, 35);
			this.choice.TabIndex = 4;
			this.choice.Text = "Выберите день недели:";
			this.choice.UseVisualStyleBackColor = true;
			// 
			// workday
			// 
			this.workday.Cursor = System.Windows.Forms.Cursors.Hand;
			this.workday.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.workday.Location = new System.Drawing.Point(44, 252);
			this.workday.Name = "workday";
			this.workday.Size = new System.Drawing.Size(141, 67);
			this.workday.TabIndex = 5;
			this.workday.Text = "Рабочий день";
			this.workday.UseVisualStyleBackColor = true;
			this.workday.Click += new System.EventHandler(this.workday_Click);
			// 
			// weekend
			// 
			this.weekend.Cursor = System.Windows.Forms.Cursors.Hand;
			this.weekend.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.weekend.Location = new System.Drawing.Point(218, 252);
			this.weekend.Name = "weekend";
			this.weekend.Size = new System.Drawing.Size(141, 67);
			this.weekend.TabIndex = 6;
			this.weekend.Text = "Выходной";
			this.weekend.UseVisualStyleBackColor = true;
			this.weekend.Click += new System.EventHandler(this.weekend_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.AliceBlue;
			this.ClientSize = new System.Drawing.Size(408, 367);
			this.Controls.Add(this.weekend);
			this.Controls.Add(this.workday);
			this.Controls.Add(this.choice);
			this.Controls.Add(this.priceInput);
			this.Controls.Add(this.price);
			this.Controls.Add(this.minutesInput);
			this.Controls.Add(this.minutes);
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.Name = "Form1";
			this.Text = "Расчет стоимости звонка";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button minutes;
		private System.Windows.Forms.TextBox minutesInput;
		private System.Windows.Forms.Button price;
		private System.Windows.Forms.TextBox priceInput;
		private System.Windows.Forms.Button choice;
		private System.Windows.Forms.Button workday;
		private System.Windows.Forms.Button weekend;
	}
}

