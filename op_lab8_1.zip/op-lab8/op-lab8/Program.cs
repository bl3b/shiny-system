﻿
using System;
class Date
{
    public uint Year { get; set; }
    public uint Month { get; set; }
    public uint Day { get; set; }

    public Date(uint year, uint month, uint day)
    {
        Year = year;
        Month = month;
        Day = day;
    }
	public Date()
	{
		while (true)
		{
			Console.WriteLine("Введите год:");
			string inputYear = Console.ReadLine();
			if (!IsValidYear(inputYear))
			{
				Console.WriteLine("Неверный формат года. Попробуйте еще раз.");
				continue;
			}
			Year = Convert.ToUInt32(inputYear);

			Console.WriteLine("Введите месяц:");
			string inputMonth = Console.ReadLine();
			if (!IsValidMonth(inputMonth))
			{
				Console.WriteLine("Неверный формат месяца. Попробуйте еще раз.");
				continue;
			}
			Month = Convert.ToUInt32(inputMonth);

			Console.WriteLine("Введите день:");
			string inputDay = Console.ReadLine();
			if (!IsValidDay(inputDay, Month, Year))
			{
				Console.WriteLine("Неверный формат дня. Попробуйте еще раз.");
				continue;
			}
			Day = Convert.ToUInt32(inputDay);

			break;
		}
	}

	private bool IsValidYear(string inputYear)
	{
		int year;
		if (!int.TryParse(inputYear, out year))
		{
			return false;
		}
		return year >= 1;
	}

	private bool IsValidMonth(string inputMonth)
	{
		int month;
		if (!int.TryParse(inputMonth, out month))
		{
			return false;
		}
		return month >= 1 && month <= 12;
	}

	private bool IsValidDay(string inputDay, uint month, uint year)
	{
		int day;
		if (!int.TryParse(inputDay, out day))
		{
			return false;
		}
		DateTime date = new DateTime((int)year, (int)month, 1);
		int maxDay = DateTime.DaysInMonth((int)year, (int)month);
		return day >= 1 && day <= maxDay;
	}
	public override string ToString()
    {
        return $"{Year}.{Month}.{Day}";
    }
    public Date AddDays(uint days)
    {
        DateTime date = new DateTime((int)Year, (int)Month, (int)Day);
        date = date.AddDays(days);
        return new Date((uint)date.Year, (uint)date.Month, (uint)date.Day);
    }
    public Date SubtractDays(uint days)
    {
        DateTime date = new DateTime((int)Year, (int)Month, (int)Day);
        date = date.AddDays(-days);
        return new Date((uint)date.Year, (uint)date.Month, (uint)date.Day);
    }
    public int CompareDates(Date otherDate)
    {
		DateTime thisDate = new DateTime((int)Year, (int)Month, (int)Day);
		DateTime other = new DateTime((int)otherDate.Year, (int)otherDate.Month, (int)otherDate.Day);
		TimeSpan difference = thisDate - other;

		if (difference.TotalDays == 0)
			return 0;
		else if (difference.TotalDays > 0)
			return 1;
		else
			return -1;
	}
    public uint DaysBetweenDates(Date otherDate)
    {
        DateTime thisDate = new DateTime((int)Year, (int)Month, (int)Day);
        DateTime other = new DateTime((int)otherDate.Year, (int)otherDate.Month, (int)otherDate.Day);
        TimeSpan difference = thisDate - other;
        return (uint)Math.Abs(difference.TotalDays);
    }
    public bool IsLeapYear()
    {
        return (Year % 4 == 0 && Year % 100 != 0) || Year % 400 == 0;
    }
    public uint GetYear()
    {
        return Year;
    }
    public uint GetMonth()
    {
        return Month;
    }
    public uint GetDay()
    {
        return Day;
    }
}
class Program
{
	static void Main()
	{
		Date date = new Date();
		while (true)
		{
			Console.WriteLine($"Выберите операцию:");
			Console.WriteLine("1. Добавить дни");
			Console.WriteLine("2. Вычесть дни");
			Console.WriteLine("3. Проверить високосный год");
			Console.WriteLine("4. Сравнить с другой датой");
			Console.WriteLine("5. Рассчитать разницу в днях между датами");
			int choice;
			try
			{
				choice = Convert.ToInt32(Console.ReadLine());
			}
			catch (FormatException)
			{
				Console.WriteLine("Неверный формат выбора операции. Попробуйте еще раз.");
				continue;
			}

			switch (choice)
			{
				case 1:
					Console.WriteLine("Введите количество дней для добавления:");
					uint daysToAdd;
					while (!uint.TryParse(Console.ReadLine(), out daysToAdd))
					{
						Console.WriteLine("Неверный формат ввода. Попробуйте еще раз.");
					}
					Date newDateAfterAdd = date.AddDays(daysToAdd);
					Console.WriteLine($"Новая дата после добавления: {newDateAfterAdd}");
					break;
				case 2:
					Console.WriteLine("Введите количество дней для вычитания:");
					uint daysToSubtract;
					while (!uint.TryParse(Console.ReadLine(), out daysToSubtract))
					{
						Console.WriteLine("Неверный формат ввода. Попробуйте еще раз.");
					}
					Date newDateAfterSubtract = date.SubtractDays(daysToSubtract);
					Console.WriteLine($"Новая дата после вычитания: {newDateAfterSubtract}");
					break;
				case 3:
					if (date.IsLeapYear())
						Console.WriteLine("Високосный год: да");
					else
						Console.WriteLine("Високосный год: нет");
					break;
				case 4:
					Date otherDate = new Date();
					int comparison = date.CompareDates(otherDate);
					if (comparison == 0)
						Console.WriteLine("Даты совпадают");
					else if (comparison > 0)
						Console.WriteLine("Новая дата произошла раньше");
					else
						Console.WriteLine("Новая дата произошла позже");
					break;
				case 5:
					Date otherDateForDiff = new Date();
					uint daysDifference = date.DaysBetweenDates(otherDateForDiff);
					Console.WriteLine($"Разница в днях между датами: {daysDifference}");
					break;
				default:
					Console.WriteLine("Неверный выбор. Попробуйте еще раз.");
					break;
			}
		}
		
	}

}
