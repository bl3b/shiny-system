using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace laba_11_2
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			List.Items.Clear();
			filteredList.Items.Clear();
			openFileDialog.Filter = "��������� �����(*.txt)|*.txt|��� �����(*.*)|*.*";
			saveFileDialog.Filter = "��������� �����(*.txt)|*.txt|��� �����(*.*)|*.*";
		}
		public train[] trains = new train[10];
		public string[] trainsList = new string[10];
		private void button1_Click(object sender, EventArgs e)
		{
			if (openFileDialog.ShowDialog() == DialogResult.Cancel)
				return;
			string filename = openFileDialog.FileName;
			StreamReader read = new StreamReader(filename);
			while (!read.EndOfStream)
			{
				List.Items.Add(read.ReadLine());
			}
			read.Close();
			for (int i = 0; i < 10; i++)
			{
				string list = List.Items[i].ToString();
				trains[i].destination = list.Remove(list.IndexOf(";"));
				trains[i].number = Convert.ToInt32(list.Remove(list.LastIndexOf(";")).Substring(list.IndexOf(" ")));
				trains[i].arrivalTime = TimeOnly.Parse(list.Substring(list.LastIndexOf(" ")));
				trainsList[i] = trains[i].destination + "; " + trains[i].number + "; " + trains[i].arrivalTime;
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			List.Sorted = false;
			string[] Dest = { "�����", "����������", "�����������", "����", "�����������", "�������", "����", "������", "�����-���������","������������"};
			Random random = new Random();


			List.Items.Clear();
			filteredList.Items.Clear();
			for (int i = 0; i < 10; i++)
			{
				trains[i].destination = Dest[random.Next(0, 10)];
				trains[i].number = random.Next(1, 970);
				trains[i].arrivalTime = new TimeOnly(random.Next(0, 24), random.Next(0, 60));
				trainsList[i] = trains[i].destination + "; " + trains[i].number + "; " + trains[i].arrivalTime;
				List.Items.Add(trainsList[i]);
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			List.Items.Clear();
			filteredList.Items.Clear();
			Array.Clear(trainsList);
			Array.Clear(trains);
		}

		private void button4_Click(object sender, EventArgs e)
		{
			string[] trains = List.Items.Cast<string>().ToArray();
			Array.Sort(trains, (x, y) =>
			{
				string[] partsX = x.Split(';');
				string[] partsY = y.Split(';');
				int numberX = int.Parse(partsX[1].Trim());
				int numberY = int.Parse(partsY[1].Trim());
				return numberX.CompareTo(numberY);
			});
			filteredList.Items.Clear();
			foreach (string train in trains)
			{
				filteredList.Items.Add(train);
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			if (saveFileDialog.ShowDialog() == DialogResult.Cancel)
				return;
			string filename = saveFileDialog.FileName;
			StreamWriter write = new StreamWriter(filename);
			for (int i = 0; i < 10; i++)
			{
				write.WriteLine(List.Items[i].ToString());
			}
			write.Close();
			MessageBox.Show("���� ��������");
		}

		private void button6_Click(object sender, EventArgs e)
		{
			filteredList.Items.Clear();
			bool Succ = int.TryParse(filter.Text, out int trainNumber);
			if (Succ)
			{
				for (int i = 0; i < 10; i++)
				{
					if (trains[i].number == trainNumber)
					{
						filteredList.Items.Add(trainsList[i]);
					}
				}
				if (filteredList.Items.Count == 0)
				{
					MessageBox.Show("����� � ����� ������� �� ������");
				}
			}
			else
			{
				MessageBox.Show("�� ����� �� �����");
			}
		}

		public struct train
		{
			public string destination;
			public int number;
			public TimeOnly arrivalTime;
		}
	}
}
