﻿namespace laba_11_2
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			openButton = new Button();
			generationButton = new Button();
			clearButton = new Button();
			sortButton = new Button();
			saveButton = new Button();
			filterButton = new Button();
			filter = new TextBox();
			List = new ListBox();
			filteredList = new ListBox();
			openFileDialog = new OpenFileDialog();
			saveFileDialog = new SaveFileDialog();
			SuspendLayout();
			// 
			// openButton
			// 
			openButton.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			openButton.Location = new Point(12, 337);
			openButton.Name = "openButton";
			openButton.Size = new Size(93, 39);
			openButton.TabIndex = 0;
			openButton.Text = "Открыть";
			openButton.UseVisualStyleBackColor = true;
			openButton.Click += button1_Click;
			// 
			// generationButton
			// 
			generationButton.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			generationButton.Location = new Point(111, 337);
			generationButton.Name = "generationButton";
			generationButton.Size = new Size(99, 39);
			generationButton.TabIndex = 1;
			generationButton.Text = "Генерация";
			generationButton.UseVisualStyleBackColor = true;
			generationButton.Click += button2_Click;
			// 
			// clearButton
			// 
			clearButton.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			clearButton.Location = new Point(216, 337);
			clearButton.Name = "clearButton";
			clearButton.Size = new Size(93, 39);
			clearButton.TabIndex = 2;
			clearButton.Text = "Очистить";
			clearButton.UseVisualStyleBackColor = true;
			clearButton.Click += button3_Click;
			// 
			// sortButton
			// 
			sortButton.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			sortButton.Location = new Point(315, 337);
			sortButton.Name = "sortButton";
			sortButton.Size = new Size(113, 39);
			sortButton.TabIndex = 3;
			sortButton.Text = "Сортировать";
			sortButton.UseVisualStyleBackColor = true;
			sortButton.Click += button4_Click;
			// 
			// saveButton
			// 
			saveButton.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			saveButton.Location = new Point(434, 337);
			saveButton.Name = "saveButton";
			saveButton.Size = new Size(96, 39);
			saveButton.TabIndex = 4;
			saveButton.Text = "Сохранить";
			saveButton.UseVisualStyleBackColor = true;
			saveButton.Click += button5_Click;
			// 
			// filterButton
			// 
			filterButton.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			filterButton.Location = new Point(631, 337);
			filterButton.Name = "filterButton";
			filterButton.Size = new Size(113, 39);
			filterButton.TabIndex = 5;
			filterButton.Text = "Фильтрация";
			filterButton.UseVisualStyleBackColor = true;
			filterButton.Click += button6_Click;
			// 
			// filter
			// 
			filter.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			filter.Location = new Point(536, 344);
			filter.Name = "filter";
			filter.Size = new Size(89, 26);
			filter.TabIndex = 6;
			// 
			// List
			// 
			List.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			List.FormattingEnabled = true;
			List.ItemHeight = 19;
			List.Location = new Point(12, 12);
			List.Name = "List";
			List.Size = new Size(339, 308);
			List.TabIndex = 7;
			// 
			// filteredList
			// 
			filteredList.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			filteredList.FormattingEnabled = true;
			filteredList.ItemHeight = 19;
			filteredList.Location = new Point(366, 12);
			filteredList.Name = "filteredList";
			filteredList.Size = new Size(378, 308);
			filteredList.TabIndex = 8;
			// 
			// openFileDialog
			// 
			openFileDialog.FileName = "openFileDialog1";
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(756, 387);
			Controls.Add(filteredList);
			Controls.Add(List);
			Controls.Add(filter);
			Controls.Add(filterButton);
			Controls.Add(saveButton);
			Controls.Add(sortButton);
			Controls.Add(clearButton);
			Controls.Add(generationButton);
			Controls.Add(openButton);
			Name = "Form1";
			Text = "Расписание поездов";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button openButton;
		private Button generationButton;
		private Button clearButton;
		private Button sortButton;
		private Button saveButton;
		private Button filterButton;
		private TextBox filter;
		private ListBox List;
		private ListBox filteredList;
		private OpenFileDialog openFileDialog;
		private SaveFileDialog saveFileDialog;
	}
}
