﻿namespace laba11
{
	partial class Form1
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.cycle = new System.Windows.Forms.Button();
			this.formula = new System.Windows.Forms.Button();
			this.n_text = new System.Windows.Forms.Button();
			this.nScrollBar = new System.Windows.Forms.HScrollBar();
			this.result1 = new System.Windows.Forms.TextBox();
			this.result2 = new System.Windows.Forms.TextBox();
			this.nText = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// cycle
			// 
			this.cycle.Location = new System.Drawing.Point(46, 111);
			this.cycle.Name = "cycle";
			this.cycle.Size = new System.Drawing.Size(168, 82);
			this.cycle.TabIndex = 0;
			this.cycle.Text = "Результат в цикле:";
			this.cycle.UseVisualStyleBackColor = true;
			this.cycle.Click += new System.EventHandler(this.cycle_Click);
			// 
			// formula
			// 
			this.formula.Location = new System.Drawing.Point(46, 225);
			this.formula.Name = "formula";
			this.formula.Size = new System.Drawing.Size(168, 82);
			this.formula.TabIndex = 1;
			this.formula.Text = "Результат по формуле:";
			this.formula.UseVisualStyleBackColor = true;
			this.formula.Click += new System.EventHandler(this.formula_Click);
			// 
			// n_text
			// 
			this.n_text.Location = new System.Drawing.Point(46, 42);
			this.n_text.Name = "n_text";
			this.n_text.Size = new System.Drawing.Size(168, 23);
			this.n_text.TabIndex = 4;
			this.n_text.Text = "Выберите n:";
			this.n_text.UseVisualStyleBackColor = true;
			// 
			// nScrollBar
			// 
			this.nScrollBar.LargeChange = 1;
			this.nScrollBar.Location = new System.Drawing.Point(246, 48);
			this.nScrollBar.Name = "nScrollBar";
			this.nScrollBar.Size = new System.Drawing.Size(179, 17);
			this.nScrollBar.TabIndex = 5;
			this.nScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.nScrollBar_Scroll);
			// 
			// result1
			// 
			this.result1.Location = new System.Drawing.Point(246, 144);
			this.result1.Name = "result1";
			this.result1.Size = new System.Drawing.Size(179, 20);
			this.result1.TabIndex = 6;
			// 
			// result2
			// 
			this.result2.Location = new System.Drawing.Point(246, 261);
			this.result2.Name = "result2";
			this.result2.Size = new System.Drawing.Size(179, 20);
			this.result2.TabIndex = 7;
			// 
			// nText
			// 
			this.nText.AutoSize = true;
			this.nText.Location = new System.Drawing.Point(243, 83);
			this.nText.Name = "nText";
			this.nText.Size = new System.Drawing.Size(67, 13);
			this.nText.TabIndex = 8;
			this.nText.Text = "Значение n:";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(547, 351);
			this.Controls.Add(this.nText);
			this.Controls.Add(this.result2);
			this.Controls.Add(this.result1);
			this.Controls.Add(this.nScrollBar);
			this.Controls.Add(this.n_text);
			this.Controls.Add(this.formula);
			this.Controls.Add(this.cycle);
			this.Name = "Form1";
			this.Text = "Вычисление выражения";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button cycle;
		private System.Windows.Forms.Button formula;
		private System.Windows.Forms.Button n_text;
		private System.Windows.Forms.HScrollBar nScrollBar;
		private System.Windows.Forms.TextBox result1;
		private System.Windows.Forms.TextBox result2;
		private System.Windows.Forms.Label nText;
	}
}

