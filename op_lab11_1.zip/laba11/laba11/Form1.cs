﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba11
{

	public partial class Form1 : Form

	{
		public Form1()
		{
			InitializeComponent();
		}

		private int CalculateExpression(object n)
		{
			int nValue = (int)n;

			if (nValue == 1)
				{
					return 1;
				}
			else
				{
					return (int)Math.Pow(nValue, 4) + CalculateExpression(nValue - 1);
				}
			
		}

		private void cycle_Click(object sender, EventArgs e)
		{
			int n = nScrollBar.Value;
			int cycle_result = CalculateExpression(n);
			result1.Text = cycle_result.ToString();
		}

		private void formula_Click(object sender, EventArgs e)
		{
			int n = nScrollBar.Value;
			double formula_result = n * (n + 1) * (2 * n + 1) * (3 * Math.Pow(n, 2) + 3 * n - 1) / 30;
			result2.Text = formula_result.ToString();

		}

		private void nScrollBar_Scroll(object sender, ScrollEventArgs e)
		{
			nScrollBar.Maximum = 1000;
			int n = nScrollBar.Value;
			nText.Text = "Значение n: " + n.ToString();
		}
	}
}
