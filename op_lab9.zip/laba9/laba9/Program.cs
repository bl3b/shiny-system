﻿using System.Text;

namespace laba9
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Введите число на клавиатуре, чтобы выбрать фигуру, посмотреть его свойства и найти площадь");
			Console.WriteLine("1. Круг");
			Console.WriteLine("2. Квадрат");
			Console.WriteLine("3. Ромб");
			while (true)
			{
				int choice = int.Parse(Console.ReadLine());
				switch (choice)
				{
					case 1:
						Round round = new Round();
						Console.WriteLine("Чтобы найти площадь круга, введите радиус круга");
						double R = double.Parse(Console.ReadLine());
						round.Area();
						Console.WriteLine(round.Area(R));
						break;
					case 2:
						Square square = new Square();
						Console.WriteLine("Чтобы найти площадь квадрата, введите длину стороны квадрата");
						double a = double.Parse(Console.ReadLine());
						square.Area();
						Console.WriteLine(square.Area(a));
						break;
					case 3:
						Rhombus rhombus = new Rhombus();
						Console.WriteLine("Чтобы найти площадь ромба, введите длину первой и второй диагонали");
						double d1 = double.Parse(Console.ReadLine());
						double d2 = double.Parse(Console.ReadLine());
						rhombus.Area();
						Console.WriteLine(rhombus.Area(d1, d2));
						break;
					default:
						Console.WriteLine("Неправильный ввод. Попробуйте снова");
						break;
				}
			}
		}
	}
}
