﻿namespace laba9
{
	internal class Rhombus : Quadrangle
	{
		public double d1;
		public double d2;
		public Rhombus()
		{
			Console.WriteLine("Все стороны ромба равны");
			Console.WriteLine("Противоположные углы ромба равны");
		}
		public double Area(double d1, double d2)
		{
			return 0.5 * d1 * d2;
		}
	}
}
