﻿namespace laba9
{
	internal class Square : Quadrangle
	{
		public double a;
		public Square()
		{
			Console.WriteLine("Все стороны ромба равны");
			Console.WriteLine("Все углы квадрата равны 90 градусов");
		}
		public double Area(double a)
		{
			return a * a;
		}
	}
}
