﻿namespace laba9
{
	internal class Quadrangle : Figure
	{
		public Quadrangle()
		{
			Console.WriteLine("Фигура, состоящая из 4 вершин");
			Console.WriteLine("Фигура, вершины которой соединены отрезками");
		}
		public override void Area()
		{
			Console.WriteLine("Площадь фигуры равна: ");
		}
	}
}