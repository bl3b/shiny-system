﻿namespace laba9
{
	internal class Round : Figure
	{
		public double R;
		public Round()
		{
			Console.WriteLine("Фигура, состоящая из множества точек, отдалённых от друг от друга на одинаковом расстоянии");
		}
		public override void Area()
		{
			Console.WriteLine("Площадь фигуры равна: ");
		}
		public double Area(double R)
		{
			return Math.PI * R * R;
		}
	}
}
