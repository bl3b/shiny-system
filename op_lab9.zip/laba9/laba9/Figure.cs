﻿namespace laba9
{
	internal abstract class Figure
	{
		public Figure()
		{
			Console.WriteLine("Геометрическая фигура");
			Console.WriteLine("Фигура, лежащая в двумерной плоскости");
		}
		public abstract void Area();

	}
}