﻿namespace laba10
{
	partial class AngleCalculator
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AngleCalculator));
			this.x = new System.Windows.Forms.Button();
			this.y = new System.Windows.Forms.Button();
			this.yInput = new System.Windows.Forms.TextBox();
			this.xInput = new System.Windows.Forms.TextBox();
			this.calculationResult = new System.Windows.Forms.TextBox();
			this.calculate = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// x
			// 
			this.x.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.x.Location = new System.Drawing.Point(142, 158);
			this.x.Name = "x";
			this.x.Size = new System.Drawing.Size(135, 86);
			this.x.TabIndex = 0;
			this.x.Text = "Введите x:";
			this.x.UseVisualStyleBackColor = true;
			// 
			// y
			// 
			this.y.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.y.Location = new System.Drawing.Point(345, 158);
			this.y.Name = "y";
			this.y.Size = new System.Drawing.Size(135, 86);
			this.y.TabIndex = 1;
			this.y.Text = "Введите y:";
			this.y.UseVisualStyleBackColor = true;
			// 
			// yInput
			// 
			this.yInput.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.yInput.Location = new System.Drawing.Point(345, 265);
			this.yInput.Name = "yInput";
			this.yInput.Size = new System.Drawing.Size(135, 31);
			this.yInput.TabIndex = 2;
			// 
			// xInput
			// 
			this.xInput.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.xInput.Location = new System.Drawing.Point(142, 265);
			this.xInput.Name = "xInput";
			this.xInput.Size = new System.Drawing.Size(135, 31);
			this.xInput.TabIndex = 3;
			// 
			// calculationResult
			// 
			this.calculationResult.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.calculationResult.Location = new System.Drawing.Point(243, 435);
			this.calculationResult.Name = "calculationResult";
			this.calculationResult.Size = new System.Drawing.Size(132, 31);
			this.calculationResult.TabIndex = 6;
			// 
			// calculate
			// 
			this.calculate.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.calculate.Location = new System.Drawing.Point(243, 329);
			this.calculate.Name = "calculate";
			this.calculate.Size = new System.Drawing.Size(132, 86);
			this.calculate.TabIndex = 7;
			this.calculate.Text = "Вычислить угол";
			this.calculate.UseVisualStyleBackColor = true;
			this.calculate.Click += new System.EventHandler(this.Calculation_Click);
			// 
			// AngleCalculator
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(626, 618);
			this.Controls.Add(this.calculate);
			this.Controls.Add(this.calculationResult);
			this.Controls.Add(this.xInput);
			this.Controls.Add(this.yInput);
			this.Controls.Add(this.y);
			this.Controls.Add(this.x);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
			this.Name = "AngleCalculator";
			this.Text = "Калькулятор угла";
			this.Load += new System.EventHandler(this.Calculation_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button x;
		private System.Windows.Forms.Button y;
		private System.Windows.Forms.TextBox yInput;
		private System.Windows.Forms.TextBox xInput;
		private System.Windows.Forms.TextBox calculationResult;
		private System.Windows.Forms.Button calculate;
	}
}

