﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba10
{
	public partial class AngleCalculator : Form
	{
		public AngleCalculator()
		{
			InitializeComponent();
		}

		private void Calculation_Load(object sender, EventArgs e)
		{
			
		}

		private void Calculation_Click(object sender, EventArgs e)
		{
			double x = 0;
			double y = 0;
			try
			{
				x = double.Parse(xInput.Text);
				y = double.Parse(yInput.Text);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Неправильный ввод. Попробуйте снова!");
			}
			if (x < 0 || y < 0)
			{
				MessageBox.Show("Неправильный ввод. Попробуйте снова!");
			}
			else
			{
				double angleRad = Math.Atan2(y, x);
				double angleDeg = angleRad * (180 / Math.PI);
				calculationResult.Text = angleDeg.ToString();
			}
		}
	}
}
