﻿using System;

public class Binary1
{
	public string IntegerPart { get; set; }
	public string FractionalPart { get; set; }

	public Binary1(string integerPart, string fractionalPart)
	{
		IntegerPart = integerPart;
		FractionalPart = fractionalPart;
	}

	public static Binary1 InputBinaryNumber(string numberPosition)
	{
		Console.WriteLine($"Введите целую часть {numberPosition} двоичного числа:");
		string integerPart = Console.ReadLine();
		while (!IsValidBinary(integerPart))
		{
			Console.WriteLine($"Введите корректную целую часть {numberPosition} двоичного числа:");
			integerPart = Console.ReadLine();
		}

		Console.WriteLine($"Введите дробную часть {numberPosition} двоичного числа:");
		string fractionalPart = Console.ReadLine();
		while (!IsValidBinary(fractionalPart))
		{
			Console.WriteLine($"Введите корректную дробную часть {numberPosition} двоичного числа:");
			fractionalPart = Console.ReadLine();
		}

		return new Binary1(integerPart, fractionalPart);
	}


	private static void Output(Binary1 binaryNumber)
	{
		Console.WriteLine(binaryNumber.IntegerPart + "." + binaryNumber.FractionalPart);
	}

	public static void Main(string[] args)
	{
		Binary1 num1 = InputBinaryNumber("первого");
		Binary1 num2 = InputBinaryNumber("второго");

		Console.WriteLine("Выберите операцию (+, *):");
		string operation = Console.ReadLine();

		Binary1 result;

		
			switch (operation)
			{
				case "+":
					result = Sum(num1, num2);
					break;
				case "*":
					result = Product(num1, num2);
					break;
				default:
					Console.WriteLine("Не существует операции " + operation);
					return;
			}
			Console.WriteLine("Результат:");
			Output(result);
		
	}

	public static Binary1 Sum(Binary1 num1, Binary1 num2)
	{
		double decimalNum1 = ConvertToDecimal(num1);
		double decimalNum2 = ConvertToDecimal(num2);

		double sum = decimalNum1 + decimalNum2;

		return ConvertToBinary(sum);
	}

	public static Binary1 Product(Binary1 num1, Binary1 num2)
	{
		double decimalNum1 = ConvertToDecimal(num1);
		double decimalNum2 = ConvertToDecimal(num2);

		double product = decimalNum1 * decimalNum2;

		return ConvertToBinary(product);
	}

	private static double ConvertToDecimal(Binary1 binaryNumber)
	{
		double integerPart = Convert.ToInt32(binaryNumber.IntegerPart, 2);
		double fractionalPart = Convert.ToDouble(Convert.ToInt32(binaryNumber.FractionalPart, 2)) / Math.Pow(2, binaryNumber.FractionalPart.Length);
		return integerPart + fractionalPart;
	}

	private static Binary1 ConvertToBinary(double number)
	{
		string integerPart = Convert.ToString((int)number, 2);
		string fractionalPart = "";
		double fractionalNumber = number - Math.Truncate(number);

		for (int i = 0; i < 4; i++)
		{
			fractionalNumber *= 2;
			fractionalPart += Math.Truncate(fractionalNumber).ToString();
			fractionalNumber -= Math.Truncate(fractionalNumber);
		}
		return new Binary1(integerPart, fractionalPart);
	}

	private static bool IsValidBinary(string binary)
	{
		foreach (char c in binary)
		{
			if (c != '0' && c != '1')
				return false;
		}
		return true;
	}
}